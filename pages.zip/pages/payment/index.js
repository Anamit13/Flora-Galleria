import Layout from '../../components/layout';
import Payment from '../../components/paydone';
import Navbar from '../../components/navbar';

const ProductPage = () => <Layout> <Navbar />  <Payment /> </Layout>


export default ProductPage;