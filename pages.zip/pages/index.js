import Navbar from '../components/navbar';
import Layout from '../components/layout';
import Carosel from '../components/carousel';
import HomeContent from '../components/home-content';
const HomePage = () => <Layout> <Navbar /> <Carosel /> <HomeContent />   </Layout>


export default HomePage;