import Layout from '../../components/layout';
import FormC from '../../components/form_content';

const ProductPage = () => <Layout>  <FormC /> </Layout>


export default ProductPage;