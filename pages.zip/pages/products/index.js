import Navbar from '../../components/navbar';
import Layout from '../../components/layout';
import Cards from '../../components/cards';

const ProductPage = () => <Layout> <Navbar /> <Cards />  </Layout>


export default ProductPage;