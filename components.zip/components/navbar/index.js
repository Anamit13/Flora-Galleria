import React from 'react';
import ReactDOM from 'react-dom';
import styles from '../layout/styles.module.css';
import Image from 'next/image';
import Link from 'next/link';





class Navbar extends React.Component{
    
    
    render(){
        const mystyle = {
            height: "30px",
            marginbottom: "10px"
        };
        const mystyle1 = {
            
            border: "1px solid white",
            color: "white"
        };
        const nav = {
            backgroundColor: "darkseagreen"
        };
    
        const searchb = {
            color: "white"
        };
      
        
        
    
        return(
        
            <nav className="navbar navbar-expand-lg navbar-dark justify-content-between" style = {nav}>
            <Link href = "/">
                <a className="navbar-brand">
                    <Image src = "/home.png" height = {30} width = {30} /> 
                </a>
            </Link>
          <ul className="navbar-nav" style = {{color:"white"}}>
            Flora Gallaria
          </ul>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">

                <ul className="navbar-nav mr-auto" style = {{marginLeft:"50px"}}>
                      <li className="nav-item dropdown">
                    <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Products
                    </a>
                    <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a className="dropdown-item" href="#">Plants</a>
                      <a className="dropdown-item" href="#">Gardening</a>
                        <a className="dropdown-item" href="#">Soils & fertilisers</a>
                        <a className="dropdown-item" href="#">Seeds</a>
                      <div className="dropdown-divider"></div>
                      <a className="dropdown-item" href="#">Gifts</a>
                    </div>
                    </li>
                     <li className="nav-item ">
                    <a className="nav-link" href="#">Nurseries </a>
                      </li>
                             <li className="nav-item ">
                        <a className="nav-link" href="#">About Us </a>
                      </li>
                        <li className="nav-item">
                        <a className="nav-link" href="#">FAQs </a>
                      </li>
                </ul>

                     <form className="form-inline my-2 my-lg-0">
                         <div className="input-group" >
                          <input className="form-control mr-sm-2" id = "search" type="search" placeholder="Type here..." aria-label="Search" list = "data" onfocus = "this.value = ''" required  />
                            <datalist id = "data">
                              <option value="Avenue Tress" />  
                              <option value="Bonsai Plants" />
                                <option value="Cactus and Succlents" />
                                <option value="Climbers and Creepers" />
                                <option value="Fruit Plants" />
                                <option value="Palms and Cycads" />
                                <option value="Herb Plants" />
                                <option value="Flower Plants" />
                            </datalist>
                            <button type="reset" style = {{backgroundColor:"transparent", border:"0px solid black"}}><Image src = "/clear.png" height = {20} width = {20} /></button>
                             <div className="input-group-append">
                            <Link href = "/products">
                          <button className="btn btn-outline-success my-2 my-sm-0" type="submit" style = {searchb}>Search</button>
                            </Link>
                             </div>
                         </div>
                    </form>
                     <ul className="navbar-nav">
                       <li className="nav-item">
                    <a className="nav-link" href="#">Login / Signup</a>
                  </li>
                    </ul>

                

              </div>
              
        

			
			</nav>



        );
        
        
        
    }
    
    
    
    
}

export default Navbar;