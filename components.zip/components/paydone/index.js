import React from 'react';
import ReactDOM from 'react-dom';
import styles from '../layout/styles.module.css';
import Image from 'next/image';
import Link from 'next/link';



class Payment extends React.Component{
    
     constructor(props){
        super(props);

        this.state = {
   
            amount:''
        }
    }
    
    
    componentDidMount() {
            this.documentData = JSON.parse(localStorage.getItem('document'));

            if (localStorage.getItem('document')) {
                this.setState({
                    amount: this.documentData.ptotal
                    
            })
        } else {
            this.setState({
                amount: ''
            })
        }
        }
    
    
    render(){
    
        return(
            
            <div className = "container-fluid">
                <div className = "row" style = {{marginTop:"30px"}}>
                    <div className = "col-sm-12">
                    <h1 style = {{color:"yellowgreen", textAlign:"center"}}>Thank You for Shopping with us!</h1>
                    </div>
                </div>
                <div className = "row" style = {{marginTop:"80px"}}>
                    <div className = "col-md-3">
                    </div>
                    <div className = "col-md-3" style = {{backgroundColor:"#F4F0CB",  border:"3px solid darkseagreen",borderRight:"0px solid darkseagreen"}}>
                        <h1>Payment details</h1><br /><br />
                        <h4>Payment Successful</h4><br />
                        <h4>Your order is a bonsai plant</h4>
                        <form>
                        <h4 style = {{backgroundColor:"transparent", border: "0px"}}> <input style = {{backgroundColor:"transparent", border: "0px"}} type="text" name="amount" value={this.state.amount} placeholder="0.00" readOnly /></h4><br />
                        </form>
                        <h4>Delivery Date: 19 Feb 2021</h4>
                        
                    </div>
                    <div className = "col-md-3" style = {{backgroundColor:"#F4F0CB", border:"3px solid darkseagreen",borderLeft:"0px solid darkseagreen"}}>
                     <Image src = "/plant_delivery.jpg" height = {320} width = {340} />
                        
                    </div>
                    <div className = "col-md-3">
                    </div>
                </div>
            </div>



        );
        
        
        
    }
    
    
    
    
}

export default Payment;