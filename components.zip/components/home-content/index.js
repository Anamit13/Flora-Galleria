import React from 'react';
import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css";

import { Carousel } from 'react-responsive-carousel';

import Image from 'next/image';

class HomeContent extends React.Component {
    render() {
        
        return (
            <div className= "container-fluid">
            <div className = "row" style = {{backgroundColor:"#DED29E"}}>
                <div className = "col-md-5 pt-4" style = {{backgroundColor:"#F4F0CB",textAlign:"center"}}>
                    <h1>Live Consultation</h1><br />
                    <h5>25 min vedio consultation with gardening experts</h5><br />
                    <h1>Worth Rs.199</h1> <br />
                    <button style = {{marginBottom: "10px"}} type="button" class="btn btn-outline-success">Buy Now</button>
                </div>
            
                <div className = "col-md-2" style = {{backgroundColor:"#DED29E", textAlign:"center"}}>
                    <div style = {{paddingTop:"80px"}}>
                    <Image className = "image-fluid" src = "/lefta.svg" height = {50} width = {50} style = {{marginTop:"80px"}} /><br/>
                    <Image className = "image-fluid" src = "/righta.svg" height = {50} width = {50} style = {{marginTop:"80px"}} />
                    </div>
                </div>
              
                <div className = "col-md-5 text - center" style = {{backgroundColor:"#F4F0CB",textAlign:"center"}}>
                    <h1>Gardening Workshops</h1><br />
                    <h5>Worshops exclusively curated to help you learn cultivating planys and joy!</h5><br />
                    <h1>Starting@ Rs.299</h1> <br />
                    <button type="button" class="btn btn-outline-success pb - 3">Buy Now</button>
           
                </div>
            </div>
            
            </div>
            
        )
    };
}

export default HomeContent;
