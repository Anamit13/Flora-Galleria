import React from 'react';
import ReactDOM from 'react-dom';
import styles from '../layout/styles.module.css';
import Image from 'next/image';
import Link from 'next/link';

class Cards extends React.Component{
    render(){
            const divout = {
                paddingLeft: "30px",
                paddingRight: "30px"
            };
            const heading = {
                paddingTop: "10px",
                fontSize: "30px"
            };
            const divin1 = {
                marginTop: "7px",
                backgroundColor: "#F4F0CB"
            };
            const divin2 = {
                marginLeft: "auto",
                marginRight: "auto",
                height: "250px",
                width: "350px",
                position: "relative",
                padding: "0px",
                marginTop: "10px"
            };
            const divin3 = {
                marginLeft: "auto",
                marginRight: "auto",
                height: "250px",
                width: "350px",
                padding: "0px",
                marginTop: "10px"
            };
            const divout2 = {
                marginTop: "30px",
                paddingLeft: "30px",
                paddingRight: "30px",
                backgroundColor: "#F4F0CB"
            };
            const divin4 = {
                marginLeft: "auto",
                marginRight: "auto",
                height: "250px",
                position: "relative",
                width: "350px",
                padding: "0px",
                marginTop: "10px"
            };
            const divin5 = {
                marginLeft: "auto",
                marginRight: "auto",
                height: "250px",
                width: "350px",
                padding: "0px",
                marginTop: "10px"
            };
           
            
              
        
        return(
            	<div className="container-fluid text-center" style={divout}>
                  <p style={heading}>Bonsai Plants and nurseries</p>
                 

                  <div className="row" style={divin1}>
                    <div className="col-sm-4" style={divin2}>	
                        <Image className="img-fluid " src="/img01.jpg" width = {200} height = {120} />
                        <p> Bonsai - Green world ujjain nursery</p>
                        <p>6, Nirman Nagar - 07342516700  </p>
                    <Link href = "/form">
                        <button type="button" className="btn btn-success">Get yours now</button>
                    </Link>
                      </div>
                    <div className="col-sm-4 text-center" style={divin3}>
                          <Image className="img-fluid " src="/img02.jpg"  width = {200} height = {120} />
                         <p> Bonsai - Ever Green nursery</p>
                        <p>27, Jawasiya Marg, Ujjain -  098273 81730  </p>
                        <button type="button" className="btn btn-success">Get yours now</button>
                    </div>
                      <div className="col-sm-4" style={divin3}>
                        <Image className="img-fluid " src="/img03.jpg"  width = {200} height = {120} />
                        <p> Bonsai - Tarun nursery</p>
                        <p>77, Dewas Road, Ujjain - 07342513700  </p>
                        <button type="button" className="btn btn-success">Get yours now</button>
                        
                      </div>
                  </div>
                    <div className="row" style={divout2}>
                      <div className="col-sm-4 text-center" style={divin4}>
                        <Image src = "/img04.jpg" className = "img-fluid" width = {200} height = {120} />
                           <p> Bonsai - Anubhav nursery</p>
                        <p>Oppo. crystal inn, Ujjain - 07342516600  </p>
                        <button type="button" className="btn btn-success">Get yours now</button>
                    </div>
                    <div className="col-sm-4 text-center" style={divin5}>
                      <Image className="img-fluid " src="/img05.jpg" width = {200} height = {120} />
                             <p> Bonsai - Kshipra Vihar nursery</p>
                        <p>57/A, Vasant Vihar, Ujjain - 0734251500  </p>
                        <button type="button" className="btn btn-success">Get yours now</button>
            
                    </div>

                    <div className="col-sm-4 text-center" style= {divin5}>
                      <Image className="img-fluid " src="/img06.jpg"  width = {200} height = {120} />
                    <p> Bonsai - Garden Botique nursery</p>
                        <p>Dhanwantari Marg, Ujjain - 07342514789 </p>
                        <button type="button" className="btn btn-success">Get yours now</button>
                    </div>

                  </div>
            </div>
        );
    }
    
    
}

export default Cards;