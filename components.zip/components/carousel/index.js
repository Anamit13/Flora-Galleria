import React from 'react';
import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css";

import { Carousel } from 'react-responsive-carousel';

import Image from 'next/image';

class Carosel extends React.Component {
    render() {
        const bg = {
            backgroundColor: "#DED29E"
        };
        const imgdiv1 = {
         
            fontSize: "20px",
            color:"yellowgreen",
            backgroundColor: "#F4F0CB",
            border:"0px solid black",
            borderRadius: "10px"
          
        };
        const imgdiv2 = {
         
            fontSize: "20px",
            color:"yellowgreen",
            backgroundColor: "#F4F0CB",
            border:"0px solid black",
            borderRadius: "10px"
          
        };
        return (
            <div className = "container-fluid" style = {bg}>
             
                <Carousel autoPlay interval="2000" transitionTime="1500" showStatus = {false}>
           
                    <div style = {bg}>
                        <Image src = "/image 01.jpg" height = {600} width = {890} />
                        <p style = {imgdiv1} className = "legend">"Happiness is having MORE and MORE plants..."</p> 
                    </div>
                    
                    <div style = {bg}>
                        <Image src = "/image 03.jpeg" height = {600} width = {890} />
                        <p className="legend" style = {imgdiv1}>"Happiness is growing your own Garden..."</p>
                    </div>
                    <div style = {bg}>
                        <Image src = "/image 04.jpeg" height = {600} width = {890} />
                        <p className="legend" style = {imgdiv1}>"Happiness is having cute succlens in your collection..."</p>
                    </div>
                    <div style = {bg}>
                        <Image src = "/image 05.jpeg" height = {600} width = {890} />
                        <p className="legend" style = {imgdiv1}>"Happiness is growing your own food..."</p>
                    </div>
                  
                  
                </Carousel>
            </div>
        )
    };
}

export default Carosel;
