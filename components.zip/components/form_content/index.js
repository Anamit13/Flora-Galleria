import React from 'react';
import { Component } from 'react';
import ReactDOM from 'react-dom';
import styles from '../layout/styles.module.css';
import Image from 'next/image';
import Link from 'next/link';

class FormC extends React.Component{
    documentData;
    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.state = {
            fname: '',
            lname: '',
            phone: '',
            email: '',
            add1: '',
            add2: '',
            city: '',
            pin: '',
            qty: '',
            ptotal:''
        }
    }
        handleChange= (e)=> {
        this.setState({
            [e.target.name]:e.target.value});
        }

        // on form submit...
    handleFormSubmit(e) {
        e.preventDefault()
       localStorage.setItem('document',JSON.stringify(this.state));
        let am = this.state.qty;
        
        const total = 349;
        const shipping = 20;
        const stotal = (total + shipping)/10;
        const subtotal = (total+shipping)-stotal;
        const price = am*subtotal;
        this.setState({ptotal:price});
        const t = console.log(price);
        console.log(t);
    }

        // React Life Cycle
        componentDidMount() {
            this.documentData = JSON.parse(localStorage.getItem('document'));

            if (localStorage.getItem('document')) {
                this.setState({
                    fname: this.documentData.fname,
                   lname: this.documentData.lname,
                   phone: this.documentData.phone,
                    email: this.documentData.email,
                    add1: this.documentData.add1,
                    add2: this.documentData.add2,
                    city: this.documentData.city,
                    pin: this.documentData.pin,
                    qty: this.documentData.qty,
                    ptotal: this.documentData.ptotal
                    
            })
        } else {
            this.setState({
                fname: '',
                lname: '',
                phone: '',
                 email: '',
                 add1: '',
                 add2: '',
                 city: '',
                 pin: '',
                qty: '',
                ptotal: ''
            })
        }
        }
    render(){
        
        return(
            <body style = {{backgroundColor: "#F4F0CB"}}>
            <form onSubmit = {this.handleFormSubmit}>
              <div className="container d-flex justify-content-center my-5" style = {{backgroundColor:"darkseagreen"}}>
    <div className="row my-2 mx-2 main">
      
        <div className="col-md-5 col-12 mycol text-center" style = {{marginTop: "0px", marginRight:"0px", textAlign:"center"}}>
            
            <h2 className="title pt-5 pb-4" style = {{color:"white"}}>Get your plant</h2>
            <Image src = "/img01.jpg" height = {170} width = {200} style = {{marginTop: "10px"}} />
             <h4 className="title pt-1 pb-1"  style = {{color:"white"}}> Bonsai Plant</h4>
            <p className="title pt-2 pb-0"  style = {{color:"white", textAlign:"left", fontSize:"20px",marginLeft:"30px"}}> Product price - Rs.349/-</p>
            <p className="title pt-0 pb-0"  style = {{color:"white", textAlign:"left", fontSize:"20px",marginLeft:"30px"}}> Shipping charges - Rs.20/-</p>
         
            <p className="title pt-0 pb-0"  style = {{color:"white", textAlign:"left", fontSize:"20px",marginLeft:"30px"}}> Subtotal (incl. taxes) - <input type = "text" name = "ptotal" readOnly  value = {this.state.ptotal} style = {{backgroundColor:"transparent", border:"0px solid black", color:"white",borderBottom:"1px solid white",width:"120px"}} placeholder = "Rs." />(Discount of 10%)</p>
            
          </div>
        <div className = "col-md-1" style = {{heigt: "50px",width: "2px", border:"0px solid black"}}>
          
            </div>
   
        <div className="col-md-6 col-12 xcol">
            <h2 className="title pt-5 pb-3" style = {{color:"white"}}>Fill the following details</h2>
        
                <div className="row rone">
                    <div className="form-group col-md-6 fone py-1"> <input required type="text" className="form-control" placeholder="First name" name = "fname" value={this.state.fname} onChange={this.handleChange} /> </div>
                    <div className="form-group col-md-6 ftwo py-1"> <input required type="text" className="form-control" placeholder="Last name" name = "lname" value={this.state.lname} onChange={this.handleChange} /> </div>
                </div>
                <div className="row rtwo">
                    <div className="form-group col-md-6 fthree py-1"> <input type="text" required className="form-control jk" placeholder="Phone" name = "phone" value={this.state.phone} onChange={this.handleChange} /> </div>
                    <div className="form-group col-md-6 ffour py-1"> <input type="email" required className="form-control lm" placeholder="Email" name = "email" value={this.state.email} onChange={this.handleChange}/> </div>
                </div>
                <div className="row rthree">
                    <div className="form-group col-md-12 ffive py-1"> <input required type="text" className="form-control" placeholder="Address 1" name = "add1" value={this.state.add1} onChange={this.handleChange} /> </div>
                 
                </div>
                  <div className="row rfour">
                    <div className="form-group col-md-12 ffive py-1"> <input required type="text" className="form-control" placeholder="Address 2" name = "add2" value={this.state.add2} onChange={this.handleChange} /> </div>
                 
                </div>
                <div className="row rfive">
                    <div className="form-group col-md-4 fthree py-1"> <input required type="text" className="form-control jk" placeholder="City" name = "city" value={this.state.city} onChange={this.handleChange} /> </div>
                    <div className="form-group col-md-4 ffour py-1"> <input required type="number" className="form-control lm" placeholder="Pin" name = "pin" value={this.state.pin} onChange={this.handleChange} /> </div>
                    <div className="form-group col-md-4 ffive py-1"> <input required type="number" className="form-control lm" placeholder="quantity" name = "qty" value={this.state.qty} onChange={this.handleChange} /> </div>
                </div>
                <div className="row rsix">
                    <div className="form-group col-md-4 fseven py-3 text-center">
                        <Link href = "/products">
                        <button type="button" className="btn btn-primary"  style = {{backgroundColor:"darkseagreen", border:"1px solid white", color:"white"}}><span>Cancel</span></button> 
                            </Link>
                    </div>
                    <div className="form-group col-md-4 feight py-3 text-center">
                   
                       <button type="submit" className="btn btn-primary"  style = {{backgroundColor:"darkseagreen", border:"1px solid white", color:"white"}}><span>Submit</span></button><br />
                    </div>
                <Link href = "/payment">
                    <div className="form-group col-md-4 fnine py-3 text-center">
                        <br /><br/>
                       <button type="button" className="btn btn-primary"  style = {{backgroundColor:"darkseagreen", border:"3px solid white", color:"white"}}><span>Make Payment</span></button><br />
                    </div>
                </Link>
                        
                           
                        
                   
                    
                </div>
        
        </div>
    </div>
        
</div>
              
            </form>
            </body>
        );
    }
}
export default FormC;